﻿// Global using directives

global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Net;
global using System.Net.Http;
global using System.Threading;
global using System.Threading.Tasks;
global using AutoFixture;
global using AutoFixture.NUnit3;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.Extensions.Logging;
global using Moq;
global using NUnit.Framework;