namespace SFA.DAS.EmployerCommitmentsV2.Web.Cookies;

public static class CookieNames
{
    public const string Authentication = "SFA.DAS.EmployerCommitmentsV2.Web.Auth";
    public const string ManageApprentices = "SFA.DAS.EmployerCommitmentsV2.ManageApprentices";
}