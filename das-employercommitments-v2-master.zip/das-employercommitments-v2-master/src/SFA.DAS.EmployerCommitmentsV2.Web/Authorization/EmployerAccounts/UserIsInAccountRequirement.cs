﻿using Microsoft.AspNetCore.Authorization;

namespace SFA.DAS.EmployerCommitmentsV2.Web.Authorization.EmployerAccounts;

public class UserIsInAccountRequirement : IAuthorizationRequirement { }