using Microsoft.AspNetCore.Authorization;

namespace SFA.DAS.EmployerCommitmentsV2.Web.Authorization.Commitments;

public class AccessApprenticeshipRequirement : IAuthorizationRequirement
{
}